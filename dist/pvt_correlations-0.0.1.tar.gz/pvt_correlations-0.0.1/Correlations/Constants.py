gas_const: float = 10.73159  # Gas Constant in psia-ft3/R-mol

mw_air: float = 28.96  # Molecular weight of air in lb/lb-mol
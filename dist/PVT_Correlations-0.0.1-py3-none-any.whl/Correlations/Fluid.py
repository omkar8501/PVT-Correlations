class Fluid:
    def __init__(self, oil_api, sg_gas):
        self.oil_api = oil_api
        self.sg_gas = sg_gas
